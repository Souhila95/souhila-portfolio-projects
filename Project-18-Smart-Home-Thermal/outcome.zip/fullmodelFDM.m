% Parameters
k_air = 0.024;  % Thermal conductivity of air [W/mK]
k_foam = 0.022; % Thermal conductivity of foam [W/mK]
k_wood = 0.12;  % Thermal conductivity of wood [W/mK]

rho_air = 1.225;     % Density of air [kg/m^3]
rho_foam = 35;       % Density of foam [kg/m^3]
rho_wood = 600;      % Density of wood [kg/m^3]

cp_air = 1005;       % Specific heat capacity of air [J/kgK]
cp_foam = 1400;      % Specific heat capacity of foam [J/kgK]
cp_wood = 2400;      % Specific heat capacity of wood [J/kgK]

L_air = 0.1;  % Thickness of air layer [m]
L_foam = 0.05;  % Thickness of foam layer [m]
L_wood = 0.05;  % Thickness of wood layer [m]

dx_air = L_air / 10;  % Spatial step for air layer
dx_foam = L_foam / 10;  % Spatial step for foam layer
dx_wood = L_wood / 10;  % Spatial step for wood layer

dt = 0.01;  % Time step [s]
time = 0:dt:3600;  % Time vector [s] (extended to 1 hour)

% Discretization points
nx_air = length(0:dx_air:L_air);
nx_foam = length(0:dx_foam:L_foam);
nx_wood = length(0:dx_wood:L_wood);

% Initial conditions
T_air = 20 * ones(nx_air, 1);    % Initial temperature in air [°C]
T_foam = 20 * ones(nx_foam, 1);  % Initial temperature in foam [°C]
T_wood = 20 * ones(nx_wood, 1);  % Initial temperature in wood [°C]

% Heat source parameters (pulse signal)
start_time = 1800; % start time of bulb ON in seconds
end_time = 2400; % end time of bulb ON in seconds
Q_bulb = @(t) 100 * (t >= start_time & t <= end_time);  % Heat source (bulb) as a function of time [W]

% Store temperature dynamics
T_air_history = zeros(length(time), nx_air);
T_foam_history = zeros(length(time), nx_foam);
T_wood_history = zeros(length(time), nx_wood);
Q_bulb_history = zeros(length(time), 1);

% Time-stepping loop
for t_idx = 1:length(time)
    t = time(t_idx);
    
    % Air layer: Finite difference method
    T_air_new = T_air;
    for i = 2:nx_air-1
        T_air_new(i) = T_air(i) + dt * k_air / (rho_air * cp_air * dx_air^2) * ...
            (T_air(i+1) - 2*T_air(i) + T_air(i-1));
    end
    % Update boundary conditions for air layer
    T_air_new(1) = T_air(1) + dt * k_air / (rho_air * cp_air * dx_air^2) * ...
        (T_air(2) - T_air(1)) + dt * Q_bulb(t) / (rho_air * cp_air * dx_air);  % Bulb heating effect
    T_air_new(end) = T_air_new(end);  % Interface with foam

    % Foam layer: Finite difference method
    T_foam_new = T_foam;
    for i = 2:nx_foam-1
        T_foam_new(i) = T_foam(i) + dt * k_foam / (rho_foam * cp_foam * dx_foam^2) * ...
            (T_foam(i+1) - 2*T_foam(i) + T_foam(i-1));
    end
    % Update boundary conditions for foam layer
    T_foam_new(1) = T_foam(1) + dt * k_foam / (rho_foam * cp_foam * dx_foam^2) * ...
        (T_foam(2) - T_foam(1)) + dt * k_air / (rho_air * cp_air * dx_air^2) * ...
        (T_air_new(end) - T_foam(1));  % Interface with air
    T_foam_new(end) = T_foam_new(end);  % Interface with wood

    % Wood layer: Finite difference method
    T_wood_new = T_wood;
    for i = 2:nx_wood-1
        T_wood_new(i) = T_wood(i) + dt * k_wood / (rho_wood * cp_wood * dx_wood^2) * ...
            (T_wood(i+1) - 2*T_wood(i) + T_wood(i-1));
    end
    % Update boundary conditions for wood layer
    T_wood_new(1) = T_wood(1) + dt * k_wood / (rho_wood * cp_wood * dx_wood^2) * ...
        (T_wood(2) - T_wood(1)) + dt * k_foam / (rho_foam * cp_foam * dx_foam^2) * ...
        (T_foam_new(end) - T_wood(1));  % Interface with foam
    T_wood_new(end) = T_wood_new(end);  % Exterior boundary condition (can be set to ambient temp.)

    % Update temperatures
    T_air = T_air_new;
    T_foam = T_foam_new;
    T_wood = T_wood_new;

    % Store data for plotting
    T_air_history(t_idx, :) = T_air;
    T_foam_history(t_idx, :) = T_foam;
    T_wood_history(t_idx, :) = T_wood;
    Q_bulb_history(t_idx) = Q_bulb(t);
end

% Plotting the results

% Plot temperature dynamics of air
figure;
mesh(time, 0:dx_air:L_air, T_air_history');
xlabel('Time [s]');
ylabel('Position in Air [m]');
zlabel('Temperature [°C]');
title('Temperature Dynamics in Air Layer');
grid on;

% Plot temperature dynamics of foam
figure;
mesh(time, L_air + (0:dx_foam:L_foam), T_foam_history');
xlabel('Time [s]');
ylabel('Position in Foam [m]');
zlabel('Temperature [°C]');
title('Temperature Dynamics in Foam Layer');
grid on;

% Plot temperature dynamics of wood
figure;
mesh(time, L_air + L_foam + (0:dx_wood:L_wood), T_wood_history');
xlabel('Time [s]');
ylabel('Position in Wood [m]');
zlabel('Temperature [°C]');
title('Temperature Dynamics in Wood Layer');
grid on;

% Plot the power of the bulb over time
figure;
plot(time, Q_bulb_history, 'LineWidth', 2);
xlabel('Time [s]');
ylabel('Bulb Power [W]');
title('Power of Heating Bulb Over Time');
grid on;
