
% y = [1;1;0;0]';
% f1 = [0;1;0;1]';
% f2 = [1;1;0;0]';
% 
% inputs = [f1;f2]; % input vector 
% outputs = [x;y];  % corresponding target output vector
% input=input';
% output=output';
outputs = targets;  % corresponding target output vector
%inputs=inputs';
%outputs=outputs';
net = newff(minmax(inputs),[40,2],{'logsig','purelin','trainlm'}); %training functions

net.trainParam.epochs = 1000;
net.trainParam.goal = 1e-25;
net.trainParam.lr = 0.01;

net = train(net, inputs, outputs); %training dataset
estimebp=net(inputs); % estimated outputs using neural network model
figure
plot(outputs,'o')
hold on
plot(estimebp,'ro')
legend('real value','estimated value')
pctErrorbp = mean(abs(estimebp-outputs)); %accuracy ( error rate)
display(pctErrorbp);
figure;
plotconfusion(outputs, estimebp);
title('Confusion Matrix for Neural Network Predictions');

% Calculate the accuracy
pctErrorbp = mean(abs(estimebp - outputs)); % error rate
accuracy = (1 - pctErrorbp) * 100; % accuracy percentage
disp(['Global Accuracy: ', num2str(accuracy), '%']);

% Calculate the average error 
error = abs(estimebp - outputs); % absolute error for each data point
avgError = mean(error(:)); % mean of all errors

% Calculate the average accuracy
accuracy = (1 - avgError) * 100; % accuracy percentage

% Display average error and accuracy
disp(['Average Error: ', num2str(avgError)]);
disp(['Average Accuracy: ', num2str(accuracy), '%']);


% gensim(net);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%TEST%%%%%%%%%%% dataset samples for testing the network
% estimetest=net(sample1);
% figure
% plot(sampleop1)
% hold on
% plot(estimetest,'ro')
% legend('real value of test','estimated value of test')
% pctErrortest = mean(abs(estimetest-sampleop1));
% display(pctErrortest);
% 

figure;
subplot(2,1,1);
plot(hybrid_w, 'b', 'LineWidth', 1.5);
hold on;
plot(w_real_expanded, 'r--', 'LineWidth', 1.5);
xlabel('Sample Index');
ylabel('Beamforming Weight w');
legend('Optimized (GA-PSO)', 'Predicted (ANN)');
title('Comparison of Beamforming Weights (w)');
grid on;

subplot(2,1,2);
plot(hybrid_theta, 'b', 'LineWidth', 1.5);
hold on;
plot(theta_expanded, 'r--', 'LineWidth', 1.5);
xlabel('Sample Index');
ylabel('Phase Shift θ');
legend('Optimized (GA-PSO)', 'Predicted (ANN)');
title('Comparison of Beamforming Weights (θ)');
grid on;
%%%

figure;
t = tiledlayout(3,1, 'TileSpacing', 'loose', 'Padding', 'compact'); 

% First subplot
nexttile;
plot(inputs(1,:), 'b');
ylabel('Magnitude', 'FontName', 'Times New Roman');
title('H_{BS-RIS} Input Data', 'FontName', 'Times New Roman');
grid on;
set(gca, 'FontName', 'Times New Roman');

% Second subplot
nexttile;
plot(inputs(2,:), 'r');
ylabel('Magnitude', 'FontName', 'Times New Roman');
title('H_{RIS-Users} Input Data', 'FontName', 'Times New Roman');
grid on;
set(gca, 'FontName', 'Times New Roman');

% Third subplot
nexttile;
plot(inputs(3,:), 'g');
xlabel('Sample Index', 'FontName', 'Times New Roman');
ylabel('Magnitude', 'FontName', 'Times New Roman');
title('H_{BS-Users} Input Data', 'FontName', 'Times New Roman');
grid on;
set(gca, 'FontName', 'Times New Roman');

% Super title
sgtitle('Input Data Distribution', 'FontName', 'Times New Roman');
