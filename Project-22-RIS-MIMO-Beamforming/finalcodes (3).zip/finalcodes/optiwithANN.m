
%% Real-Time Optimization with GA, PSO, and Hybrid GA-PSO
global net;

%%%%% Without ANN
% Constants
rng(222); % Ensure reproducibility
c = 299792458; % Speed of light in m/s
frequency = 28e9; % Frequency in mmWave band (28 GHz)
wavelength = c / frequency; % Wavelength calculation

% Parameters
maxUsers = 35; % Maximum number of users
K_factor = 10; % Rician K-factor
numUsers = 25; % Number of users
N_BS = 8; % Number of base station antennas
N_RIS = 64; % Number of RIS elements
BS_location = [0, 0, 10]; % Fixed Base Station location
RIS_location = [5, 0, 5]; % Fixed RIS location
maxBounds = [10, 10, 10]; % Space boundaries (x, y, z)
sigma2 = 1e-9; % Noise power (W)
P_BS_max = 10; % Power budget at BS (Watts)
quantization_levels = 4; % Number of RIS phase quantization levels


%%%%  RIS Element Layout (Uniform Planar Array)
% Define RIS spacing 
RIS_spacing = wavelength / 2; % Half-wavelength spacing
%calculate RIS positions 
numRows = ceil(sqrt(N_RIS)); % Number of rows in RIS layout
numCols = ceil(N_RIS / numRows); % Number of columns
[ris_x, ris_y] = meshgrid(0:numCols-1, 0:numRows-1);

% Flatten into vectors
ris_x = ris_x(:);
ris_y = ris_y(:);

% Adjust the number of elements to exactly match N_RIS
if length(ris_x) > N_RIS
    ris_x = ris_x(1:N_RIS);
    ris_y = ris_y(1:N_RIS);
elseif length(ris_x) < N_RIS
    % If somehow fewer elements are generated, pad with zeros (unlikely scenario)
    ris_x = [ris_x; zeros(N_RIS - length(ris_x), 1)];
    ris_y = [ris_y; zeros(N_RIS - length(ris_y), 1)];
end

% Adjust spacing and centering
ris_x = RIS_spacing * (ris_x - mean(ris_x)); % X-coordinates
ris_y = RIS_spacing * (ris_y - mean(ris_y)); % Y-coordinates

% Create 3D positions of RIS elements
RIS_positions = RIS_location + [ris_x, ris_y, zeros(N_RIS, 1)];

%%%%

% User Locations and Mobility
userLocations = rand(numUsers, 3) .* maxBounds; % Initial user locations

%% Functions
% Path Loss
function PL = path_loss(d, wavelength)
    PL = (wavelength / (4 * pi * d))^2; % Linear scale
end

% Generate Channels with Rician Fading
function [H_BS_RIS, H_RIS_Users, H_BS_Users] = generate_channels(userLocations, RIS_positions, BS_location, N_BS, N_RIS, numUsers, wavelength, K_factor, maxBounds)
    LOS_component = 1; % Line-of-sight
    NLOS_component = sqrt(1 / (1 + K_factor));

    H_BS_RIS = zeros(N_RIS, N_BS);
    H_RIS_Users = zeros(numUsers, N_RIS);
    H_BS_Users = zeros(numUsers, N_BS);

    % BS ↔ RIS channel
    for i = 1:N_RIS
        d_BS_RIS = norm(RIS_positions(i, :) - BS_location);
        PL_BS_RIS = path_loss(d_BS_RIS, wavelength);
        H_BS_RIS(i, :) = sqrt(PL_BS_RIS) * (LOS_component + NLOS_component * (randn(1, N_BS) + 1j * randn(1, N_BS))) / sqrt(2);
    end

    % RIS ↔ Users channel
    for k = 1:numUsers
        for i = 1:N_RIS
            d_RIS_User = norm(userLocations(k, :) - RIS_positions(i, :));
            PL_RIS_User = path_loss(d_RIS_User, wavelength);
            H_RIS_Users(k, i) = sqrt(PL_RIS_User) * (LOS_component + NLOS_component * (randn + 1j * randn)) / sqrt(2);
        end
    end

    % BS ↔ Users channel
    for k = 1:numUsers
        d_BS_User = norm(userLocations(k, :) - BS_location);
        PL_BS_User = path_loss(d_BS_User, wavelength);
        H_BS_Users(k, :) = sqrt(PL_BS_User) * (LOS_component + NLOS_component * (randn(1, N_BS) + 1j * randn(1, N_BS))) / sqrt(2);
    end
end
%%%%
%%%%data organization
tic;

% Convert to real values
H_BS_RIS = real(H_BS_RIS);
H_RIS_Users = real(H_RIS_Users);
H_BS_Users = real(H_BS_Users);

% Convert to column vectors
H1 = H_BS_RIS(:);
H2 = H_RIS_Users(:);
H3 = H_BS_Users(:);
% Define the required number of samples
num_samples = 1280;

% Replicate and trim each vector to exactly 1280 elements
H1_rep = repmat(H1, ceil(num_samples / numel(H1)), 1);
H2_rep = repmat(H2, ceil(num_samples / numel(H2)), 1);
H3_rep = repmat(H3, ceil(num_samples / numel(H3)), 1);

H1_rep = H1_rep(1:num_samples);
H2_rep = H2_rep(1:num_samples);
H3_rep = H3_rep(1:num_samples);

% Concatenate into input_data (3 × 1280)
input_data = [H1_rep, H2_rep, H3_rep]';


% Display size
disp("Size of input_data: "), disp(size(input_data)); % Should be (3 × max_len)
%%%
target_data=net(input_data);
 % Ensure proper expansion for beamforming weights
    w_real_expanded = target_data(1, :);

    % Expand theta to fit RIS elements
    theta_expanded = target_data(2, :);
%%%
time_ann_gapso = toc;
% Achievable Sum Rate
function R = compute_sum_rate(w, theta, H_BS_RIS, H_RIS_Users, H_BS_Users, sigma2)
    numUsers = size(H_RIS_Users, 1);
    R = 0;
    for k = 1:numUsers
        h_eff = H_BS_Users(k, :) * w + H_RIS_Users(k, :) * diag(exp(1j * theta)) * H_BS_RIS * w;
        signal_power = abs(h_eff)^2;
        SINR = signal_power / sigma2;
        R = R + log2(1 + SINR);
    end
end


% Power Consumption
function power = compute_power(w, theta)
    power = norm(w)^2 + sum(abs(exp(1j * theta))); % Beamforming and RIS operation power
end

% Quantize RIS Phases
function quantized_theta = quantize_phases(theta, quantization_levels)
    step_size = 2 * pi / quantization_levels;
    quantized_theta = step_size * round(theta / step_size);
end
%%%
 
%%%%%

% Genetic Algorithm (GA) Optimization
% function [optimized_w, optimized_theta, fitness_log] = optimize_ga(H_BS_RIS, H_RIS_Users, H_BS_Users, N_BS, N_RIS, P_BS_max, sigma2, maxGenerations, popSize, quantization_levels)
%     % Initialize Population
%     population_w = randn(N_BS, popSize) + 1j * randn(N_BS, popSize); % Random beamforming
%     population_theta = 2 * pi * rand(N_RIS, popSize); % Random RIS phase shifts
% 
%     fitness_log = zeros(1, maxGenerations); % Track fitness per generation
%%%%%
tic;
% Genetic Algorithm (GA) Optimization
function [optimized_w, optimized_theta, fitness_log] = optimize_ga(H_BS_RIS, H_RIS_Users, H_BS_Users, N_BS, N_RIS, P_BS_max, sigma2, maxGenerations, popSize, quantization_levels)
    % Initialize Population
    population_w = randn(N_BS, popSize) + 1j * randn(N_BS, popSize); % Random beamforming
    population_theta = 2 * pi * rand(N_RIS, popSize); % Random RIS phase shifts

    fitness_log = zeros(1, maxGenerations); % Track fitness per generation

    % GA Optimization Loop
    for gen = 1:maxGenerations
        % Fitness Evaluation
        fitness = zeros(1, popSize);
        for i = 1:popSize
            w = sqrt(P_BS_max) * population_w(:, i) / norm(population_w(:, i)); % Normalize power
            theta = quantize_phases(population_theta(:, i), quantization_levels); % Quantize RIS phases
            fitness(i) = compute_sum_rate(w, theta, H_BS_RIS, H_RIS_Users, H_BS_Users, sigma2);
        end
        fitness_log(gen) = max(fitness); % Log best fitness

        % Selection: Keep the top half of the population
        [~, idx] = sort(fitness, 'descend');
        top_w = population_w(:, idx(1:popSize / 2));
        top_theta = population_theta(:, idx(1:popSize / 2));

        % Crossover and Mutation
        new_population_w = top_w;
        new_population_theta = top_theta;
        for i = 1:(popSize / 2)
            p1 = randi(size(top_w, 2));
            p2 = randi(size(top_w, 2));
            child_w = (top_w(:, p1) + top_w(:, p2)) / 2;
            child_theta = mean([top_theta(:, p1), top_theta(:, p2)], 2);
            new_population_w(:, end + 1) = child_w;
            new_population_theta(:, end + 1) = child_theta;
        end
        % Apply Mutation
        mutation_rate = 0.1; % Probability of mutation
        mutation_indices = rand(size(new_population_theta)) < mutation_rate;
        new_population_theta(mutation_indices) = 2 * pi * rand(sum(mutation_indices(:)), 1);

        population_w = new_population_w(:, 1:popSize); % Trim population
        population_theta = new_population_theta(:, 1:popSize);
    end
    [~, best_idx] = max(fitness);
    optimized_w = population_w(:, best_idx);
    optimized_theta = quantize_phases(population_theta(:, best_idx), quantization_levels);
end


%%%
% Particle Swarm Optimization (PSO)
function [optimized_w, optimized_theta, fitness_log] = optimize_pso(H_BS_RIS, H_RIS_Users, H_BS_Users, N_BS, N_RIS, P_BS_max, sigma2, numParticles, maxIterations, quantization_levels)
    % Initialize Particle Positions and Velocities
    particle_w = randn(N_BS, numParticles) + 1j * randn(N_BS, numParticles); % Random beamforming
    particle_theta = 2 * pi * rand(N_RIS, numParticles); % Random RIS phases
    velocity_w = randn(N_BS, numParticles) * 0.1;
    velocity_theta = randn(N_RIS, numParticles) * 0.1;

    % Fitness Evaluation
    fitness = zeros(1, numParticles);
    best_local_fitness = -Inf(1, numParticles);
    best_local_w = particle_w;
    best_local_theta = particle_theta;

    % Global Best
    [global_best_fitness, best_idx] = max(fitness);
    global_best_w = particle_w(:, best_idx);
    global_best_theta = particle_theta(:, best_idx);

    fitness_log = zeros(1, maxIterations);

    % PSO Loop
    for iter = 1:maxIterations
        for i = 1:numParticles
            % Normalize Power
            w = sqrt(P_BS_max) * particle_w(:, i) / norm(particle_w(:, i));
            theta = quantize_phases(particle_theta(:, i), quantization_levels);
            fitness(i) = compute_sum_rate(w, theta, H_BS_RIS, H_RIS_Users, H_BS_Users, sigma2);

            % Update Local Best
            if fitness(i) > best_local_fitness(i)
                best_local_fitness(i) = fitness(i);
                best_local_w(:, i) = particle_w(:, i);
                best_local_theta(:, i) = particle_theta(:, i);
            end
        end

        % Update Global Best
        [current_best_fitness, best_idx] = max(fitness);
        if current_best_fitness > global_best_fitness
            global_best_fitness = current_best_fitness;
            global_best_w = particle_w(:, best_idx);
            global_best_theta = particle_theta(:, best_idx);
        end

        % Velocity Update 
        for i = 1:numParticles
            velocity_w(:, i) = 0.5 * velocity_w(:, i) + rand * (best_local_w(:, i) - particle_w(:, i)) + ...
                rand * (global_best_w - particle_w(:, i));
            velocity_theta(:, i) = 0.5 * velocity_theta(:, i) + rand * (best_local_theta(:, i) - particle_theta(:, i)) + ...
                rand * (global_best_theta - particle_theta(:, i));
        end

        % Position Update
        particle_w = particle_w + velocity_w;
        particle_theta = particle_theta + velocity_theta;

        fitness_log(iter) = global_best_fitness;
    end
    optimized_w = global_best_w;
    optimized_theta = quantize_phases(global_best_theta, quantization_levels);
end

% Hybrid GA-PSO Optimization
function [optimized_w, optimized_theta, fitness_log] = optimize_hybrid(H_BS_RIS, H_RIS_Users, H_BS_Users, N_BS, N_RIS, P_BS_max, sigma2, ga_generations, ga_pop_size, pso_particles, pso_iterations, quantization_levels)
    % GA Phase
    [ga_w, ga_theta, ~] = optimize_ga(H_BS_RIS, H_RIS_Users, H_BS_Users, N_BS, N_RIS, P_BS_max, sigma2, ga_generations, ga_pop_size, quantization_levels);

    % Use GA result as initialization for PSO
    particle_w = repmat(ga_w, 1, pso_particles) + (randn(N_BS, pso_particles) + 1j * randn(N_BS, pso_particles)) * 0.1;
    particle_theta = repmat(ga_theta, 1, pso_particles) + randn(N_RIS, pso_particles) * 0.1;

    [optimized_w, optimized_theta, fitness_log] = optimize_pso(H_BS_RIS, H_RIS_Users, H_BS_Users, N_BS, N_RIS, P_BS_max, sigma2, pso_particles, pso_iterations, quantization_levels);
end


%% Simulation
maxGenerations = 20;
popSize = 50;
numParticles = 30;
maxIterations = 15;

% Generate Initial Channels
[H_BS_RIS, H_RIS_Users, H_BS_Users] = generate_channels(userLocations, RIS_positions, BS_location, N_BS, N_RIS, numUsers, wavelength, 10, maxBounds);

% GA Optimization
[ga_w, ga_theta, ga_fitness_log] = optimize_ga(H_BS_RIS, H_RIS_Users, H_BS_Users, N_BS, N_RIS, P_BS_max, sigma2, maxGenerations, popSize, quantization_levels);

% PSO Optimization
[pso_w, pso_theta, pso_fitness_log] = optimize_pso(H_BS_RIS, H_RIS_Users, H_BS_Users, N_BS, N_RIS, P_BS_max, sigma2, numParticles, maxIterations, quantization_levels);

% Hybrid Optimization
[hybrid_w, hybrid_theta, hybrid_fitness_log] = optimize_hybrid(H_BS_RIS, H_RIS_Users, H_BS_Users, N_BS, N_RIS, P_BS_max, sigma2, maxGenerations, popSize, numParticles, maxIterations, quantization_levels);

%% Plot Results

% Compute Power and Energy Efficiency Metrics
ga_power = compute_power(ga_w, ga_theta);
pso_power = compute_power(pso_w, pso_theta);
hybrid_power = compute_power(hybrid_w, hybrid_theta);

% Align lengths of fitness logs for plotting
minLength = min([length(ga_fitness_log), length(pso_fitness_log), length(hybrid_fitness_log)]);

% Truncate fitness logs to the same length for plotting
ga_fitness_log = ga_fitness_log(1:minLength);
pso_fitness_log = pso_fitness_log(1:minLength);
hybrid_fitness_log = hybrid_fitness_log(1:minLength);

% % Plot fitness logs
% figure;
% plot(1:minLength, ga_fitness_log, '-o', 'LineWidth', 2); hold on;
% plot(1:minLength, pso_fitness_log, '-s', 'LineWidth', 2);
% plot(1:minLength, hybrid_fitness_log, '-x', 'LineWidth', 2);
% grid on; legend('GA', 'PSO', 'Hybrid GA-PSO');
% xlabel('Iterations'); ylabel('Achievable Sum Rate (bps/Hz)');
% title('Optimization Performance Comparison');

% Find the point where the sum rate converges to a threshold
convergence_threshold = 0.9 * max(ga_fitness_log); % ex: 90% of the max sum rate
ga_convergence = find(ga_fitness_log >= convergence_threshold, 1);
pso_convergence = find(pso_fitness_log >= convergence_threshold, 1);
hybrid_convergence = find(hybrid_fitness_log >= convergence_threshold, 1);

disp(['GA Convergence: ', num2str(ga_convergence)]);
disp(['PSO Convergence: ', num2str(pso_convergence)]);
disp(['Hybrid GA-PSO Convergence: ', num2str(hybrid_convergence)]);

time_hybrid_gapso = toc;
figure;
bar([ga_power, pso_power, hybrid_power]);
set(gca, 'XTickLabel', {'GA', 'PSO', 'Hybrid GA-PSO'});
ylabel('Power Consumption (Watts)');
title('Power Consumption Comparison');


ga_energy_efficiency = ga_fitness_log(end) / ga_power;
pso_energy_efficiency = pso_fitness_log(end) / pso_power;
hybrid_energy_efficiency = hybrid_fitness_log(end) / hybrid_power;

% Display energy efficiency comparison
disp(['GA Energy Efficiency: ', num2str(ga_energy_efficiency)]);
disp(['PSO Energy Efficiency: ', num2str(pso_energy_efficiency)]);
disp(['Hybrid GA-PSO Energy Efficiency: ', num2str(hybrid_energy_efficiency)]);



disp('GA Optimized Beamforming and RIS Phases:');
disp(ga_w);
disp(ga_theta);

disp('PSO Optimized Beamforming and RIS Phases:');
disp(pso_w);
disp(pso_theta);

disp('Hybrid GA-PSO Optimized Beamforming and RIS Phases:');
disp(hybrid_w);
disp(hybrid_theta);
%%%%%%

%Comparaisson of ANN ga pso and hybrid ga pso 

%% Power Consumption and Energy Efficiency Calculation

% Extract dimensions
[N_BS, num_samples] = size(w_real_expanded);
N_RIS = size(theta_expanded, 1);

% Assumed RIS element power consumption 
P_element = 1e-3; % 1 mW per RIS element

% Compute transmit power at the BS for each sample
P_tx = sum(abs(w_real_expanded).^2, 1); % Summing power across all BS antennas

% Compute RIS power consumption 
P_RIS = N_RIS * P_element;

% Compute total power consumption
P_total = P_tx + P_RIS;

% Achievable sum rate calculation (approximation)
sigma2 = 1e-13; % Noise power (-100 dBm)
R_sum = sum(log2(1 + abs(theta_expanded).^2 ./ sigma2), 1); 

% Compute energy efficiency (bits per Joule)
EE = R_sum ./ P_total;

%% Plot Power Consumption & Energy Efficiency
figure;

subplot(2,1,1);
plot(1:num_samples, P_total, 'b-o', 'LineWidth', 1.5);
xlabel('Sample Index');
ylabel('Total Power Consumption (W)');
title('Total Power Consumption Over Time');
grid on;

subplot(2,1,2);
plot(1:num_samples, EE, 'r-s', 'LineWidth', 1.5);
xlabel('Sample Index');
ylabel('Energy Efficiency (bits/Joule)');
title('Energy Efficiency Over Time');
grid on;

% Display key values
%fprintf('Average Power Consumption for ANN-GAPSO: %.4f W\n', mean(P_total));
%fprintf('Average Energy Efficiency for ANN-GAPSO : %.4f bits/Joule\n', mean(EE)); %% Power Consumption and Energy Efficiency Calculation for GA-PSO Hybrid

% Extract dimensions
[N_BS, num_samples] = size(hybrid_w);
N_RIS = size(hybrid_theta, 1);

% Assumed RIS element power consumption 
P_element = 1e-3; % 1 mW per RIS element

% Compute transmit power at the BS for each sample (Hybrid GA-PSO)
P_tx_hybrid = sum(abs(hybrid_w).^2, 1); % Summing power across all BS antennas

% Compute RIS power consumption 
P_RIS_hybrid = N_RIS * P_element;

% Compute total power consumption
P_total_hybrid = P_tx_hybrid + P_RIS_hybrid;

% Achievable sum rate calculation 
sigma2 = 1e-13; % Noise power (-100 dBm)
R_sum_hybrid = sum(log2(1 + abs(hybrid_theta).^2 ./ sigma2), 1);

% Compute energy efficiency (bits per Joule)
EE_hybrid = R_sum_hybrid ./ P_total_hybrid;

%% Power Consumption Comparison (Bar Chart)
figure;
bar([mean(P_total), mean(P_total_hybrid)], 'FaceColor', 'flat');
set(gca, 'XTickLabel', {'GA-PSO with ANN', 'Hybrid GA-PSO'});
ylabel('Power Consumption (W)');
title('Average Power Consumption Comparison');
grid on;
%%%%%%% Energy Efficiency Comparison (Bar Chart)
figure;
bar([mean(EE), mean(EE_hybrid)], 'FaceColor', 'flat');
set(gca, 'XTickLabel', {'GA-PSO with ANN', 'Hybrid GA-PSO'});
ylabel('Energy Efficiency (bits/Joule)');
title('Average Energy Efficiency Comparison');
grid on;


% Display key values in console
fprintf('Average Power Consumption for ANN-GAPSO: %.4f W\n', mean(P_total));
fprintf('Average Energy Efficiency for ANN-GAPSO : %.4f bits/Joule\n', mean(EE));
fprintf('Average Power Consumption for GA-PSO Hybrid: %.4f W\n', mean(P_total_hybrid));
fprintf('Average Energy Efficiency for GA-PSO Hybrid: %.4f bits/Joule\n', mean(EE_hybrid));


%%%Time comparaisson 
%% Display Execution Times
fprintf('Execution Time for ANN-GAPSO: %.4f seconds\n', time_ann_gapso);
fprintf('Execution Time for Hybrid GA-PSO: %.4f seconds\n', time_hybrid_gapso);

%% Plot Execution Time Comparison
figure;
bar([time_ann_gapso, time_hybrid_gapso]); % Create bar chart
xticklabels({'GA-PSO with ANN', 'Hybrid GA-PSO'});
ylabel('Execution Time (seconds)');
title('Execution Time Comparison');
grid on;


%%%%%%
% Given sum rate values
sumrate_hybrid = 522.84;
sumrate_ann = 466.00;

% Labels for methods
methods = {'Hybrid GA-PSO', 'ANN-GA-PSO'};

% Data for bar chart
sum_rates = [sumrate_hybrid, sumrate_ann];

% Plot bar chart
figure;
bar(sum_rates, 0.5, 'FaceColor', 'b');
xticks(1:2);
xticklabels(methods);
ylabel('Sum Rate (bps/Hz)');
title('Comparison of Sum Rate Performance');
grid on;

% Annotate the values
for i = 1:2
    text(i, sum_rates(i) + 5, sprintf('%.2f', sum_rates(i)), ...
         'HorizontalAlignment', 'center', 'FontSize', 12, 'FontWeight', 'bold');
end
%%%%%%
% 
% % Convert theta to diagonal matrix
% Theta_hybrid = diag(exp(1j * hybrid_theta));  
% 
% % Initialize SNR storage
% num_users = 25;  
% snr_hybrid = zeros(1, num_users);
% snr_ann = zeros(1, num_users);
% 
% % Compute SNR for each user
% for k = 1:num_users
%     % Hybrid GA-PSO Effective Channel
%     h_eff_hybrid = H_BS_Users(k, :)' + H_BS_RIS' * Theta_hybrid * H_RIS_Users(k, :)';
% 
%     % Compute SNR
%     snr_hybrid(k) = (abs(h_eff_hybrid' * hybrid_w)^2) / sigma2;
% 
%     % ANN-GA-PSO Effective Channel
%     Theta_ann = diag(exp(1j * theta_ann_reshaped));  % Convert to diagonal matrix
%     h_eff_ann = H_BS_Users(k, :)' + H_BS_RIS' * Theta_ann * H_RIS_Users(k, :)';
% 
%     % Compute SNR
%     snr_ann(k) = (abs(h_eff_ann' * w_ann_reshaped)^2) / sigma2;
% end
% 
% % Convert to dB
% snr_hybrid_db = 10 * log10(snr_hybrid);
% snr_ann_db = 10 * log10(snr_ann);
% 
% % Plot SNR Comparison
% figure;
% plot(1:num_users, snr_hybrid_db, '-o', 'LineWidth', 2, 'MarkerSize', 6, 'DisplayName', 'Hybrid GA-PSO');
% hold on;
% plot(1:num_users, snr_ann_db, '-s', 'LineWidth', 2, 'MarkerSize', 6, 'DisplayName', 'ANN-GA-PSO');
% grid on;
% xlabel('User Index');
% ylabel('SNR (dB)');
% title('SNR Comparison: Hybrid GA-PSO vs. ANN-GA-PSO');
% legend;
% 
% % Check for NaN/Inf
% snr_hybrid(isnan(snr_hybrid) | isinf(snr_hybrid)) = 0;
% snr_ann(isnan(snr_ann) | isinf(snr_ann)) = 0;
% 
% % Convert to dB
% snr_hybrid_db = 10 * log10(snr_hybrid + eps);  % Add eps to avoid log(0)
% snr_ann_db = 10 * log10(snr_ann + eps);
% 
% % Debugging: Print values
% disp('SNR Hybrid (dB):');
% disp(snr_hybrid_db);
% disp('SNR ANN (dB):');
% disp(snr_ann_db);
% 
%%%%%
% function SNR_values = calculate_SNR_ANN(w_real_expanded, theta_expanded, H_BS_RIS, H_RIS_Users, H_BS_Users, sigma2)
%     numUsers = size(H_RIS_Users, 1); % Number of users
%     N_RIS = size(H_BS_RIS, 1); % Number of RIS elements
%     SNR_values = zeros(1, numUsers);
% 
%     % Ensure theta is a diagonal matrix
%     Theta_matrix = diag(exp(1j * theta_expanded(:))); % (N_RIS × N_RIS)
% 
%     for k = 1:numUsers
%         % Effective channel: Direct BS-User link + RIS-assisted link
%         h_eff = H_BS_Users(k, :) * w_real_expanded(:) + ... % Direct link
%                 H_RIS_Users(k, :) * Theta_matrix * H_BS_RIS * w_real_expanded(:); % RIS-assisted link
% 
%         % Compute received power
%         signal_power = abs(h_eff)^2;
% 
%         % Compute SNR
%         SNR_values(k) = signal_power / sigma2;
%     end
% end
% 
% % Compute SNR for ANN-based beamforming and RIS phases
% SNR_ANN = calculate_SNR_ANN(w_real_expanded, theta_expanded, H_BS_RIS, H_RIS_Users, H_BS_Users, sigma2);
% 
% % Display results
% disp("Average SNR (ANN-based): " + mean(10*log10(SNR_ANN)) + " dB");
% 
% % Plot SNR per user
% figure;
% plot(1:numel(SNR_ANN), 10*log10(SNR_ANN), 'b-o', 'LineWidth', 1.5, 'DisplayName', 'ANN-Based');
% xlabel('User Index');
% ylabel('SNR (dB)');
% title('SNR for ANN-Based Beamforming');
% legend;
% grid on;

%%%%
%%%%

function SNR_ANN = calculate_SNR_ANN(w_real_expanded, theta_expanded, H_BS_RIS, H_RIS_Users, H_BS_Users, sigma2)
    % === Step 1: Restore Original Dimensions ===
    num_beams = size(H_BS_Users, 2);  
    num_RIS = size(H_BS_RIS, 1);      

    % Ensure w_real_expanded matches original beamforming vector size (8 × 1)
    w_real = reshape(w_real_expanded(1:num_beams), [num_beams, 1]); 

    % Ensure theta_expanded matches original RIS phase shifts (64 × 1)
    theta = theta_expanded(1:num_RIS);  
    theta = exp(1j * theta); % Convert phase shifts to complex representation

    % === Step 2: Compute Effective Channel ===
    h_eff = zeros(size(H_BS_Users, 1), 1); % Preallocate for multiple users

    for k = 1:size(H_BS_Users, 1)
        h_eff(k) = H_BS_Users(k, :) * w_real + ...  % Direct BS-User link
                   H_RIS_Users(k, :) * diag(theta) * H_BS_RIS * w_real; % RIS-assisted link
    end

    % === Step 3: Compute SNR ===
    received_power = abs(h_eff).^2; % Power received at users
    SNR_ANN = received_power / sigma2; % SNR Calculation
end

%%%%%%
% Compute total power consumption for ANN-based approach
P_tx_ANN = sum(abs(w_real_expanded).^2, 1); % Transmit power at BS
P_RIS_ANN = N_RIS * P_element; % RIS power consumption
P_total_ANN = P_tx_ANN + P_RIS_ANN; % Total power consumption

% Compute total power consumption for Hybrid GA-PSO
P_tx_hybrid = sum(abs(hybrid_w).^2, 1);
P_RIS_hybrid = N_RIS * P_element;
P_total_hybrid = P_tx_hybrid + P_RIS_hybrid;

% Generate N_BS values
N_BS_values = 1:N_BS; 

% Compute corresponding power consumption for each N_BS
P_total_ANN_values = mean(P_total_ANN) * (N_BS_values / N_BS); % Scale based on N_BS
P_total_hybrid_values = mean(P_total_hybrid) * (N_BS_values / N_BS);

% Plot the results
figure;
plot(N_BS_values, P_total_ANN_values, 'r-o', 'LineWidth', 2, 'MarkerSize', 6); hold on;
plot(N_BS_values, P_total_hybrid_values, 'b-s', 'LineWidth', 2, 'MarkerSize', 6);
grid on;
xlabel('Number of BS Antennas (N_BS)');
ylabel('Power Consumption (W)');
title('Power Consumption vs. Number of BS Antennas');
legend('GA-PSO with ANN', 'Hybrid GA-PSO', 'Location', 'northwest');
set(gca, 'FontSize', 12);
%%%%

%%%%%%


