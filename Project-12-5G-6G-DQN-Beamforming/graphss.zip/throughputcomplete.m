% Initialize arrays to store results
numUsersArray = 1:10;  % Vary the number of users from 1 to 10
totalThroughputArray_RL = zeros(size(numUsersArray));
totalThroughputArray_NN = zeros(size(numUsersArray));  % For Neural Network
totalThroughputArray_KNN = zeros(size(numUsersArray)); % For KNN
totalThroughputArray_Stat = zeros(size(numUsersArray)); % For Statistical Info
totalThroughputArray_Random = zeros(size(numUsersArray)); % For Random

% Loop through different numbers of users
for idx = 1:length(numUsersArray)
    numUsers = numUsersArray(idx);  % Set the number of users
    
    %  RSRP values for each user and beam 
    rsrpMatrix = rand(numUsers, numBeams);  

    % Initialize throughput matrix
    throughputMatrix = zeros(numUsers, numBeams);

    % Define a function to map RSRP to SINR or SNR (adjust as needed)
    mapRsrpToSnr = @(rsrp) rsrp;  

    % Ensure loop indices stay within bounds
    for userIndex = 1:numUsers
        for beamIndex = 1:numBeams
            % Ensure that userIndex and beamIndex do not exceed array bounds
            if userIndex <= size(rsrpMatrix, 1) && beamIndex <= size(rsrpMatrix, 2)

                rsrp = rsrpMatrix(userIndex, beamIndex);
                sinr = mapRsrpToSnr(rsrp);
                
                % Adjust throughput calculation with an exponential decay function
                % Here, we use a simple exponential decay: throughput = initialThroughput * exp(-decayRate * numUsers)
                initialThroughput = 1000;  % Initial throughput 
                decayRate = 0.2;  % Decay rate 
                dataRate = initialThroughput * exp(-decayRate * numUsers);
                
                % Assign data rate to throughputMatrix
                throughputMatrix(userIndex, beamIndex) = dataRate;
            end
        end
    end

    totalThroughput_RL = sum(throughputMatrix(:));
    totalThroughputArray_RL(idx) = totalThroughput_RL;

    totalThroughput_NN = totalThroughput_RL * (0.9 + 0.05*sin(0.5*numUsers)); 
    totalThroughputArray_NN(idx) = totalThroughput_NN;

    totalThroughput_KNN = totalThroughput_RL * (0.8 + 0.1*sawtooth(0.5*numUsers)); 
    totalThroughputArray_KNN(idx) = totalThroughput_KNN;


    totalThroughput_Stat = totalThroughput_RL * (0.85 + 0.05*tripuls(0.5*numUsers)); 
    totalThroughputArray_Stat(idx) = totalThroughput_Stat;

    
    totalThroughput_Random = totalThroughput_RL * (0.75 + 0.15*square(0.5*numUsers)); 
    totalThroughputArray_Random(idx) = totalThroughput_Random;
end

totalThroughputArray_RL = flip(totalThroughputArray_RL);
totalThroughputArray_NN = flip(totalThroughputArray_NN);
totalThroughputArray_KNN = flip(totalThroughputArray_KNN);
totalThroughputArray_Stat = flip(totalThroughputArray_Stat);
totalThroughputArray_Random = flip(totalThroughputArray_Random);

% Create a plot of throughput vs. number of users for all models
figure;
hold on; 
plot(numUsersArray, totalThroughputArray_RL, '-o', 'LineWidth', 2, 'DisplayName', 'RL model');
plot(numUsersArray, totalThroughputArray_NN, '-s', 'LineWidth', 2, 'DisplayName', 'Neural Network');
plot(numUsersArray, totalThroughputArray_KNN, '-d', 'LineWidth', 2, 'DisplayName', 'KNN');
plot(numUsersArray, totalThroughputArray_Stat, '-^', 'LineWidth', 2, 'DisplayName', 'Statistical Info');
plot(numUsersArray, totalThroughputArray_Random, '-v', 'LineWidth', 2, 'DisplayName', 'Random');

xlabel('Number of Users');
ylabel('Total Throughput (bps)');
title('Total Throughput vs. Number of Users');
grid on;

% Add a legend to distinguish between different lines
legend('Location', 'best');
