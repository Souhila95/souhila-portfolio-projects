% Parameters
rho = 1.225; % density of air in kg/m^3
cp = 1005; % specific heat capacity of air in J/(kg·K)
V = 1; % volume of the room in m^3 (assuming 1x1x1 m^3 cube)
C = rho * cp * V; % thermal capacitance in J/K
h = 10; % convective heat transfer coefficient in W/(m^2·K)
A = 6; % surface area of the cube in m^2 (6 faces, each 1 m^2)
T_inf = 20; % ambient temperature in °C
% Define the power input as a pulse signal
start_time = 1800; % start time of bulb ON in seconds
end_time = 2400; % end time of bulb ON in seconds
P = @(t) 100 * (t >= start_time & t <= end_time); % 100 W between start_time and end_time
% Define the ODE
dTdt = @(t, T) (P(t) - h*A*(T - T_inf)) / C;
% Initial temperature inside the room
T0 = 20; % initial temperature in °C
% Time span for the simulation
tspan = [0 3600]; % simulate for 1 hour
% Solve the ODE
[t, T] = ode45(dTdt, tspan, T0);
% Define the power input over time
P_value = arrayfun(P, t); % Evaluate power input function at each time point
% Plotting the results
figure;
% Plot temperature (theta)
subplot(2, 1, 1);
plot(t, T, 'b-', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Temperature (°C)');
title('Temperature Variation Inside the Room');
grid on;
hold on;
% Highlight the period when the bulb is on
fill([start_time end_time end_time start_time], [min(T) min(T) max(T) max(T)], 'k', 'FaceAlpha', 0.1, 'EdgeColor', 'none');
legend('Temperature', 'Bulb On Period');
hold off;
% Plot power input
subplot(2, 1, 2);
plot(t, P_value, 'r--', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Power Input (W)');
title('Power Input of the Bulb Over Time');
grid on;
hold on;
% Highlight the period when the bulb is on
fill([start_time end_time end_time start_time], [0 0 100 100], 'k', 'FaceAlpha', 0.1, 'EdgeColor', 'none');
legend('Power Input', 'Bulb On Period');
hold off;