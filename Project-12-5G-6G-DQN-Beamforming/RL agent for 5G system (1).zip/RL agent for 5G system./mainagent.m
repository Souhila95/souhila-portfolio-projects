% Set the random generator seed for reproducibility
clc
clear 
close all

%%%%Define Environment%%%%%%%
rng(222)

ussageofcollectedData = true;
if ussageofcollectedData
    
    %%%Generating using RSRP signals for Beam Selection
     %%%method
    load nnBS_one
    load nnBS_two
    load nnBS_three
else
    % Generate data
    helperNNBSGenerateData(); 
    position.posTX = prm.posTx;
    position.ScatPos = prm.ScatPos;
end
locationMat = locationMatTrain(1:4:end,:);

% Classing location in clockwise order
secLen = size(locationMat,1)/4;
[~,b1] = sort(locationMat(1:secLen,2));
[~,b2] = sort(locationMat(secLen+1:2*secLen,1));
[~,b3] = sort(locationMat(2*secLen+1:3*secLen,2),"descend");
[~,b4] = sort(locationMat(3*secLen+1:4*secLen,1),"descend");
idx = [b1;secLen+b2;2*secLen+b3;3*secLen+b4];

locationMat =  locationMat(idx,:);

% Compute Reference Signal Received Power (RSRP) average for each base station beam and sorting in clockwise order
avgRsrpMatTrain = rsrpMatTrain/4;    % prm.NRepeatSameLoc=4;
avgRsrpMatTrain = 100*avgRsrpMatTrain./max(avgRsrpMatTrain, [],"all");
avgRsrpMatTrain = avgRsrpMatTrain(:,:,idx);
avgRsrpMatTrain = mean(avgRsrpMatTrain,1);

% Angle rotation matrix: update beam numbers : ( nBeams>4)

txBeamAng = [-55,3,96,188];
rotAngleMat = [
    0 85 170 105
    85 0 85 170
    170 85 0 85
    105 170 85 0];
rotAngleMat = 100*rotAngleMat./max(rotAngleMat,[],"all");

% start training environment creation using collected data
envTrain = BeamSelectEnv(locationMat,avgRsrpMatTrain,rotAngleMat,position);

%%%%%%%%% Create Agent %%%%%%%%

obsInfo = getObservationInfo(envTrain);
actInfo = getActionInfo(envTrain);
agent = rlDQNAgent(obsInfo,actInfo);



criticNetwork = getModel(getCritic(agent));
analyzeNetwork(criticNetwork)
figure
 plot(criticNetwork)
 title('deep learning network analyzer architechture')


% 
% opt = rlDQNAgentOptions(EpsilonGreedyExploration=0.3);
% opt = rlDQNAgentOptions(UseDoubleDQN=0.5);
opt = rlQAgentOptions('SampleTime',0.7);
opt.DiscountFactor = 0.95;
opt.EpsilonGreedyExploration.Epsilon = 0.99;
opt = rlDQNAgentOptions('MiniBatchSize',64);
opt.SampleTime = 0.8;
%%%%%
myActorOpts=rlOptimizerOptions(LearnRate=0.2, ...
    GradientThresholdMethod="absolute-value");
myActorOpts.GradientThreshold = 20;
myAgentOpt = rlACAgentOptions( ...
    "ActorOptimizerOptions",myActorOpts);

%%%%%%
agent.AgentOptions.CriticOptimizerOptions.LearnRate = 1e-4;
agent.AgentOptions.EpsilonGreedyExploration.EpsilonDecay = 1e-5;
disp(opt)

%%%%% Train Agent %%%%%% 
trainOpts = rlTrainingOptions(...
    MaxEpisodes=700, ...
    MaxStepsPerEpisode=200, ...         %  data size = 200
    StopTrainingCriteria="AverageSteps", ...
    StopTrainingValue=700, ...
    Plots="training-progress"); 



startTraining =true;
if startTraining
    trainingStats = train(agent,envTrain,trainOpts); 
else
    load("four.mat")       
end



%%%%%%%% Simulate Trained Agent %%%%%%

locationMat = locationMatTest(1:4:end,:);

% Sorting location in clockwise order
secLen = size(locationMat,1)/4;
[~,b1] = sort(locationMat(1:secLen,2));  
[~,b2] = sort(locationMat(secLen+1:2*secLen,1));
[~,b3] = sort(locationMat(2*secLen+1:3*secLen,2),"descend");
[~,b4] = sort(locationMat(3*secLen+1:4*secLen,1),"descend");
idx = [b1;secLen+b2;2*secLen+b3;3*secLen+b4];

locationMat =  locationMat(idx,:);

% Calculating Average RSRP
avgRsrpMatTest = rsrpMatTest/4;  % 4 = prm.NRepeatSameLoc;
avgRsrpMatTest = 150*avgRsrpMatTest./max(avgRsrpMatTest, [],"all");
avgRsrpMatTest = avgRsrpMatTest(:,:,idx);
avgRsrpMatTest = mean(avgRsrpMatTest,1);

% Creating 5G test environment
environementTest = BeamSelectEnv(locationMat,avgRsrpMatTest,rotAngleMat,position);

plot(environementTest)

legend({'base station (gNB)','channel scatterers','selected beam'})
title('Improved Simulation of 5G environement with beamforming and RL agent')
%%%%%% simulation of 5G environement reinforced with reinforcement learning
%%%%%% %%
sim(environementTest,agent,rlSimulationOptions("MaxSteps",100))

%%%%% SHOWCASING AGENT ACCURACY AND MAXIMUM RSRP%%%%%%%
maxPosibleRsrp = sum(max(squeeze(avgRsrpMatTest)));
rsrpSim =  environementTest.EpisodeRsrp;
disp("Agent RSRP/Maximum RSRP = " + rsrpSim/maxPosibleRsrp*100 +"%")

figure
histogram(avgRsrpMatTrain)
title('RSRP average mean for training agent accuracy (training data)')
figure
histogram(avgRsrpMatTest)
title('RSRP average mean for testing agent accuracy (data test)')
figure
bubblechart(locationMatTest(:,1),locationMatTest(:,2),locationMatTest(:,3))
title('Location path coordinates made for UE to follow')

x=maxPosibleRsrp;
disp('x=');
disp(x);
 disp('x is the maximum Possible Rsrp')

