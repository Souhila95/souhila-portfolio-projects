% Parameters
k_air = 0.024; % W/mK
rho_air = 1.225; % kg/m^3
cp_air = 1005; % J/(kg·K)
Delta_x_air = 0.1; % m (discretization step for air)

k_foam = 0.022; % W/mK
rho_foam = 35; % kg/m^3
cp_foam = 1400; % J/(kg·K)
Delta_x_foam = 0.1; % m (discretization step for foam)

k_wood = 0.12; % W/mK
rho_wood = 600; % kg/m^3
cp_wood = 2400; % J/(kg·K)
Delta_x_wood = 0.1; % m ( discretization step for wood)

% Define the time-varying power input as a pulse signal
start_time = 1800; % start time of bulb ON in seconds
end_time = 2400; % end time of bulb ON in seconds
P = @(t) 100 * (t >= start_time & t <= end_time); % 100 W between start_time and end_time

% State matrix A
A = [-k_air/(rho_air * cp_air * Delta_x_air^2), k_air/(rho_air * cp_air * Delta_x_air^2), 0;
     k_foam/(rho_foam * cp_foam * Delta_x_foam^2), - (k_foam + k_wood)/(rho_foam * cp_foam * Delta_x_foam^2), k_wood/(rho_wood * cp_wood * Delta_x_wood^2);
     0, k_foam/(rho_foam * cp_foam * Delta_x_foam^2), -k_wood/(rho_wood * cp_wood * Delta_x_wood^2)];

% Input matrix B
B = [1 / (rho_air * cp_air); 0; 0]; % will be manually applied

% Output matrix C
C = eye(3);

% Feedthrough matrix D
D = [0];

% Create state-space system
sys = ss(A, B, C, D);

% Time vector
t = 0:10:3600; % simulation time from 0 to 3600 seconds

% Define the power input signal over time
P_signal = arrayfun(P, t); % Evaluate power input function at each time point

% Initial conditions
x0 = [20; 20; 20]; % initial temperatures in air, foam, and wood

% Simulate the system
[y, ~, x] = lsim(sys, P_signal, t, x0);

% Plot temperature variations
figure;

% Temperature in Air
subplot(3, 1, 1);
plot(t, y(:,1), 'b-', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Temperature in Air (°C)');
title('Temperature Variation in Air');
grid on;

% Temperature in Foam
subplot(3, 1, 2);
plot(t, y(:,2), 'r-', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Temperature in Foam (°C)');
title('Temperature Variation in Foam');
grid on;

% Temperature in Wood
subplot(3, 1, 3);
plot(t, y(:,3), 'g-', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Temperature in Wood (°C)');
title('Temperature Variation in Wood');
grid on;

% Plot power input
figure;
plot(t, P_signal, 'k--', 'LineWidth', 2);
xlabel('Time (s)');
ylabel('Power Input (W)');
title('Power Input of the Bulb Over Time');
grid on;

% Highlight the period when the bulb is on
hold on;
fill([start_time end_time end_time start_time], [0 0 100 100], 'k', 'FaceAlpha', 0.1, 'EdgeColor', 'none');
legend('Power Input', 'Bulb On Period');
hold off;
