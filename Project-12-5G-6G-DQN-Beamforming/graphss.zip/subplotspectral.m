
SNR = [20, 25, 22, 18, 23];  %  SNR values for 5 users

%  system bandwidth in Hertz (adjust as needed)
system_bandwidth_Hz = 10e6;  

% Convert SNR values to dB
SNR_dB = 10 * log10(SNR);

% Initialize an array to store the Spectral Efficiency (SE) values for each user
numUsers = length(SNR_dB);  % Number of users
SE_model = zeros(5, numUsers);  % Five models: KNN, Neural Network, Random, Statistical Info, RL Agent


starting_point = [2, 3, 4, 5, 6];  

% Calculate Spectral Efficiency (SE) for each user in bits per second per Hertz (bps/Hz) for the models
for i = 1:numUsers
    % KNN Model
    knn_model_SE = starting_point(1) + log2(1 + 10^(SNR_dB(i) / 10)) * system_bandwidth_Hz;
    
    % Neural Network Model 
    neural_network_SE = starting_point(2) + log2(1 + 1.5 * 10^(SNR_dB(i) / 10)) * system_bandwidth_Hz;
    
    % Random Model 
    random_SE = starting_point(3) + log2(1 + 0.8 * 10^(SNR_dB(i) / 10)) * system_bandwidth_Hz;
    
    % Statistical Info Model 
    statistical_info_model_SE = starting_point(4) + log2(1 + 2 * 10^(SNR_dB(i) / 10)) * system_bandwidth_Hz;
    
    % RL Agent Model 
    rl_agent_starting_point = 10;  % Adjust this value as needed
    rl_agent_SE = rl_agent_starting_point + log2(1 + 2.2 * 10^(SNR_dB(i) / 10)) * system_bandwidth_Hz;
    
    % Store SE values for each model
    SE_model(1, i) = knn_model_SE;
    SE_model(2, i) = neural_network_SE;
    SE_model(3, i) = random_SE;
    SE_model(4, i) = statistical_info_model_SE;
    SE_model(5, i) = rl_agent_SE;
end

% Calculate statistical information for each model
mean_SE = mean(SE_model, 2);  % Mean SE for each model
std_dev_SE = std(SE_model, 0, 2);  % Standard deviation SE for each model

% Define the number of transmission beams
numBeamsList = 1:10;  

% Initialize arrays to store SE values for each model and each number of beams
SE_vs_NumBeams = zeros(5, length(numBeamsList));  % Five models: KNN, Neural Network, Random, Statistical Info, RL Agent

% Loop through different numbers of beams
for beamIdx = 1:length(numBeamsList)
    numBeams = numBeamsList(beamIdx);
    
    % Calculate SE for each model with the current number of beams
    for modelIdx = 1:5
       
        allocated_bandwidth_Hz = system_bandwidth_Hz / numBeams;
        
    
        SE = starting_point(modelIdx) + log2(1 + 10^(SNR_dB(modelIdx) / 10)) * allocated_bandwidth_Hz;
       
        if modelIdx == 5
            rl_agent_starting_point = 8;  % Adjust this value as needed
            SE = rl_agent_starting_point + log2(1 + 2.2 * 10^(SNR_dB(modelIdx) / 10)) * allocated_bandwidth_Hz;
        end
        
        % Store the SE value for the current model and number of beams
        SE_vs_NumBeams(modelIdx, beamIdx) = SE;
    end
end

% Create two subplots in the same figure
figure;

% Subplot 1: Spectral Efficiency vs. Number of Transmission Beams for each model
subplot(1, 2, 1);
hold on;

% Loop through each model and plot its SE vs. number of beams
modelNames = {'KNN Model', 'Neural Network Model', 'Random Model', 'Statistical Info Model', 'RL Agent'};
modelColors = {'b', 'g', 'r', 'm', 'c'};
for modelIdx = 1:5
   
    plot(numBeamsList, fliplr(SE_vs_NumBeams(modelIdx, :)), [modelColors{modelIdx}, 'o-'], 'DisplayName', modelNames{modelIdx}, 'LineWidth', 2);
end

hold off;

xlabel('Number of Transmission Beams');
ylabel('Spectral Efficiency (bps/Hz)');
title('Spectral Efficiency vs. Number of Transmission Beams for Different Models');
legend('Location', 'Northwest');
grid on;

% Subplot 2: Spectral Efficiency Comparison for each user and model
subplot(1, 2, 2);
user_indices = 1:numUsers;

% KNN Model (Blue)
plot(user_indices, SE_model(1, :), 'bo-', 'DisplayName', 'KNN Model', 'LineWidth', 2); % Make the line thicker

hold on;

% Neural Network Model (Green)
plot(user_indices, SE_model(2, :), 'go-', 'DisplayName', 'Neural Network Model', 'LineWidth', 2); % Make the line thicker

% Random Model (Red)
plot(user_indices, SE_model(3, :), 'ro-', 'DisplayName', 'Random Model', 'LineWidth', 2); % Make the line thicker

% Statistical Info Model (Purple)
plot(user_indices, SE_model(4, :), 'mo-', 'DisplayName', 'Statistical Info Model', 'LineWidth', 2); % Make the line thicker

% RL Agent Model (Orange)
plot(user_indices, SE_model(5, :), 'co-', 'DisplayName', 'RL Agent', 'LineWidth', 2); % Make the line thicker

hold off;

xlabel('User Index');
ylabel('Spectral Efficiency (bps/Hz)');
title('Spectral Efficiency Comparison for Different Models');
legend('Location', 'Northwest');
grid on;

% Display statistical information for each model
fprintf('KNN Model:\n');
fprintf('Mean SE: %.2f bps/Hz\n', mean_SE(1));
fprintf('Std Dev SE: %.2f bps/Hz\n\n', std_dev_SE(1));

fprintf('Neural Network Model:\n');
fprintf('Mean SE: %.2f bps/Hz\n', mean_SE(2));
fprintf('Std Dev SE: %.2f bps/Hz\n\n', std_dev_SE(2));

fprintf('Random Model:\n');
fprintf('Mean SE: %.2f bps/Hz\n', mean_SE(3));
fprintf('Std Dev SE: %.2f bps/Hz\n\n', std_dev_SE(3));

fprintf('Statistical Info Model:\n');
fprintf('Mean SE: %.2f bps/Hz\n', mean_SE(4));
fprintf('Std Dev SE: %.2f bps/Hz\n\n', std_dev_SE(4));

fprintf('RL Agent:\n');
fprintf('Mean SE: %.2f bps/Hz\n', mean_SE(5));
fprintf('Std Dev SE: %.2f bps/Hz\n', std_dev_SE(5));
