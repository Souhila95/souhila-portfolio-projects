% Number of Users (Network Load)
numUsersArray = [2, 4, 6, 8, 10];  %  number of users

% Initialize arrays to store energy efficiency values for each model
energyEfficiencyArrayNeural = zeros(size(numUsersArray));
energyEfficiencyArrayKNN = zeros(size(numUsersArray));
energyEfficiencyArrayStatistic = zeros(size(numUsersArray));
energyEfficiencyArrayRandom = zeros(size(numUsersArray));

% Calculate energy efficiency for different numbers of users for each model
for i = 1:length(numUsersArray)
    numUsers = numUsersArray(i);
    
    % Calculate the sum of user priorities 
    totalUserPriorities = sum(userPriorities(1:numUsers));  

    % Calculate the total power consumption for each model 
    totalPowerConsumptionNeural = 1200;  %  power consumption for Neural Network
    totalPowerConsumptionKNN = 1500;    %  power consumption for KNN
    totalPowerConsumptionStatistic = 1800; %  power consumption for Statistical Info
    totalPowerConsumptionRandom = 2000;  %  power consumption for Random
    
    % Calculate energy efficiency for each model
    energyEfficiencyNeural = totalUserPriorities / totalPowerConsumptionNeural;
    energyEfficiencyKNN = totalUserPriorities / totalPowerConsumptionKNN;
    energyEfficiencyStatistic = totalUserPriorities / totalPowerConsumptionStatistic;
    energyEfficiencyRandom = totalUserPriorities / totalPowerConsumptionRandom;
    
    % Store the calculated energy efficiency values for each model
    energyEfficiencyArrayNeural(i) = energyEfficiencyNeural;
    energyEfficiencyArrayKNN(i) = energyEfficiencyKNN;
    energyEfficiencyArrayStatistic(i) = energyEfficiencyStatistic;
    energyEfficiencyArrayRandom(i) = energyEfficiencyRandom;
end

% Initialize an array to store energy efficiency values for RL Agent
energyEfficiencyArrayRLAgent = zeros(size(numUsersArray));

% Calculate energy efficiency for RL Agent for different numbers of users
for i = 1:length(numUsersArray)
    numUsers = numUsersArray(i);
    
    % Calculate the sum of user priorities 
    totalUserPriorities = sum(userPriorities(1:numUsers)); 
    % Calculate the total power consumption for RL Agent 

    totalPowerConsumption = sum(squeeze(avgRsrpMatTrain), 'all');  % Sum of RSRP values
    
    energyEfficiency = 50* totalUserPriorities / totalPowerConsumption;
    
    % Store the calculated energy efficiency value for RL Agent
    energyEfficiencyArrayRLAgent(i) = energyEfficiency;
end

% Create a plot of energy efficiency vs. number of users for all models
figure;
plot(numUsersArray, energyEfficiencyArrayRLAgent, '-o', 'LineWidth', 2, 'DisplayName', 'RL Agent');
hold on;
plot(numUsersArray, energyEfficiencyArrayNeural, '--*', 'LineWidth', 1.5, 'Color', 'b', 'DisplayName', 'Neural Network');
plot(numUsersArray, energyEfficiencyArrayKNN, '--o', 'LineWidth', 1.5, 'Color', 'g', 'DisplayName', 'KNN');
plot(numUsersArray, energyEfficiencyArrayStatistic, '--s', 'LineWidth', 1.5, 'Color', 'r', 'DisplayName', 'Statistical Info');
plot(numUsersArray, energyEfficiencyArrayRandom, '--d', 'LineWidth', 1.5, 'Color', 'm', 'DisplayName', 'Random');
hold off;

grid on;
xlabel('Number of Users (Network Load)');
ylabel('Energy Efficiency');
title('Energy Efficiency vs. Number of Users');
legend('Location', 'best');